package com.iiitd.dsavisualizer.algorithms.sorting.bubble;

// BubbleSortData
public class BubbleSortData {
    public int data;
    public int index;
}