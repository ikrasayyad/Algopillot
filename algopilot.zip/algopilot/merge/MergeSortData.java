package com.iiitd.dsavisualizer.algorithms.sorting.merge;

// MergeSortData
public class MergeSortData {
    public int data;
    public int index;
}