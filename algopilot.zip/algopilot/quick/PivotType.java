package com.iiitd.dsavisualizer.algorithms.sorting.quick;

// Enum class
// Used in QuickSort pivot selection
public enum PivotType {
    FIRST,
    MIDDLE,
    END
}